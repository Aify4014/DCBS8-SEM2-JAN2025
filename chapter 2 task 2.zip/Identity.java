package hu2;

import java.util.Scanner;

public class Identity {
    public static void main(String[] args) {
        // Create a scanner object to read input
        Scanner info = new Scanner(System.in);
        System.out.print("Enter your name: ");
        String name = info.nextLine();
        System.out.print("Enter your age: ");
        int age = info.nextInt();
        
        info.nextLine();  
        System.out.print("Enter your hobby: ");
        String hobby = info.nextLine();
        System.out.print("Enter your favorite food: ");
        String favoriteFood = info.nextLine();

        // Displaying the collected information
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("Hobby: " + hobby);
        System.out.println("Favorite Food: " + favoriteFood);

       
        info.close();
    }
}
