package hu2;

public class CompoundProg{
	    public static void main(String[] args) {
	        System.out.println("What is a++ ?");
	        System.out.println("a++ is a post-increment operator that adds one to the value of (a) and then");
	        System.out.println("returns the value of (a).");
	        System.out.println();
	        System.out.println("What is ++a ?");
	        System.out.println("++a is a pre-increment operator that increases the value of a before using");
	        System.out.println("it in an expression.");
	        System.out.println("What is b-- ?");
	        System.out.println("b-- is Decrements the value after the current expression is evaluated.");
	        System.out.println();
	        System.out.println("    What is --b");
	        System.out.println("--b is Decrements the value before the current expression is evaluated.");
	    }
	}