/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication5;

/**
 *
 * @author User
 */
import java.util.Scanner;

public class ArithmeticProg {

    public static void main(String[] args) {

        int num1 = 0, num2 = 0;

        // Create a Scanner object for user input
        Scanner baca = new Scanner(System.in);

        // Prompt the user for the first number
        System.out.print("Masukkan nombor pertama: ");
        num1 = baca.nextInt();

        // Prompt the user for the second number
        System.out.print("Masukkan nombor kedua: ");
        num2 = baca.nextInt();

        // Performing arithmetic operations and display the results
        System.out.println("Tambah: " + num1 + " + " + num2 + " = " + (num1 + num2));
        System.out.println("Darab: " + num1 + " x " + num2 + " = " + (num1 * num2));
        System.out.println("Bahagi: " + num1 + " / " + num2 + " = " + (num1 / num2));
        System.out.println("Tolak: " + num1 + " - " + num2 + " = " + (num1 - num2)); 
        System.out.println("Modulus: " + num1 + " % " + num2 + " = " + (num1 % num2));

        
        baca.close();
    }
}
