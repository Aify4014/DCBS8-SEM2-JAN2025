package hu2;

import javax.swing.JOptionPane;

public class BMI {
    public static void main(String[] args) {
        // Get weight and height inputs from the user (using integers)
        String weightInput = JOptionPane.showInputDialog("Enter your weight (in kg):");
        String heightInput = JOptionPane.showInputDialog("Enter your height (in centimeters):");

        // Convert inputs to integers
        int weight = Integer.parseInt(weightInput);
        int heightCm = Integer.parseInt(heightInput);

        // Convert height from centimeters to meters (integer)
        int heightM = heightCm / 100;  // Integer division

        // Calculate BMI using the formula: BMI = weight / (height * height)
        int bmi = weight / (heightM * heightM);

        // Display the result in a pop-up message
        JOptionPane.showMessageDialog(null, "Your BMI is: " + bmi);
    }
}