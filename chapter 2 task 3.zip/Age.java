package hu2;

import javax.swing.JOptionPane;
public class Age {
   public static void main(String[] args) {
       String firstNumber;
       String secondNumber;
       int num1, num2, sum;
       
       firstNumber = JOptionPane.showInputDialog("Enter the current year");
       secondNumber = JOptionPane.showInputDialog("Enter your born year");
       num1 = Integer.parseInt(firstNumber);
       num2 = Integer.parseInt(secondNumber);
       sum = num1 - num2;
      
       JOptionPane.showMessageDialog(null, "your age  is "+sum, "Results",     JOptionPane.PLAIN_MESSAGE);
       System.exit(0);
    } 
}