/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */

//import scanner class
import java.util.Scanner; 

public class Age {

    public static void main(String[] args) {
        Scanner nombor = new Scanner(System.in);
        
        //declare variables
        int birthYear, currentYear, age;

        //ask user to enter the current year
        System.out.print("Enter the current year: ");
        currentYear = nombor.nextInt();

        //ask user to enter the birth year
        System.out.print("Enter your birth year: ");
        birthYear = nombor.nextInt();

        //calculate the age using subtraction of the year 
        age = currentYear - birthYear;

        //display the calculated age
        System.out.println("Your age is: " + age + " years old");

       //close the scanner
        nombor.close();
    }
}