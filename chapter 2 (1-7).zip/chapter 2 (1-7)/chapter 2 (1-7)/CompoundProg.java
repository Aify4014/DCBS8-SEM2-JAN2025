/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */

//import the scanner class
import java.util.Scanner;

public class CompoundProg {
    public static void main(String[] args) {
        //declare and initialize variables
        int x = 5;
        int y;

        //demonstrate Pre-Increment (++x)
        System.out.println("PRE-INCREMENT (++x)");
        System.out.println("# The value of a is incremented before it is used in the expression.");
        System.out.println("# The new value of a is returned for use.");
        System.out.println("value of x: " + x);
        y = ++x; //increment x first, then assign to y
        System.out.println("After Pre-Increment (++x):");
        System.out.println("x = " + x); //x is incremented to 6
        System.out.println("y = " + y); //y gets the new value of x (6)

        //reset x for the next demonstration
        x = 5;
        
        //demonstrate Post-Increment (x++)
        System.out.println("\nPRE-INCREMENT (x++)");
        System.out.println("# Uses the current value of a in the expression before incrementing it.");
        System.out.println("# The original value is returned, and a is incremented afterward.");
        System.out.println("value of x: " + x);
        y = x++; //assign x to y first, then increment x
        System.out.println("After Post-Increment (x++):");
        System.out.println("x = " + x); //x is incremented to 6
        System.out.println("y = " + y); //y gets the old value of x (5)

        //reset x for the next demonstration
        x = 5;

        //demonstrate Pre-Decrement (--x)
        System.out.println("\nPRE-INCREMENT (--x)");
        System.out.println("# Decrements the value of b before using it in the expression.");
        System.out.println("# The decremented value is returned for use.");
        System.out.println("value of x: " + x);
        y = --x; //decrement x first, then assign to y
        System.out.println("After Pre-Decrement (--x):");
        System.out.println("x = " + x); //x is decremented to 4
        System.out.println("y = " + y); //y gets the new value of x (4)

        //reset x for the next demonstration
        x = 5;

        //demonstrate Post-Decrement (x--)
        System.out.println("\nPRE-INCREMENT (x--)");
        System.out.println("# Uses the current value of b in the expression before decrementing it.");
        System.out.println("# The original value of b is returned for use.");
        System.out.println("value of x: " + x);
        y = x--; //assign x to y first, then decrement x
        System.out.println("After Post-Decrement (x--):");
        System.out.println("x = " + x); //x is decremented to 4
        System.out.println("y = " + y); //y gets the old value of x (5)
    }
}