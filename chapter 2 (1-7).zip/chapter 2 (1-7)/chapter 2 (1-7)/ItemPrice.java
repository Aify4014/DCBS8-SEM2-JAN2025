/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */

//imp[ort the scanner class
import java.util.Scanner;

public class ItemPrice {
    public static void main(String[] args) {
       
        Scanner kira = new Scanner(System.in);

       //ask the user to enter item name 
        System.out.print("Enter item name: ");
        String itemName = kira.nextLine();

        //ask the user to enter item price 
        System.out.print("Enter item price: ");
        double price = kira.nextDouble();

        //ask the user to enter quantity of the item
        System.out.print("Enter quantity: ");
        int quantity = kira.nextInt();

        //ask the user to enter discount rate 
        System.out.print("Enter discount rate (in percentage): ");
        double discountRate = kira.nextDouble();

        //calculate the total price 
        double totalPrice = price * quantity;

        //calculate the discount 
        double discountAmount = totalPrice * (discountRate / 100);

        //calculate the final price after discount 
        double priceAfterDiscount = totalPrice - discountAmount;

        //display the item details and price calculations
        System.out.println("\nItem Details:");
        System.out.println("Item Name: " + itemName);
        System.out.println("Price per Item: " + price);
        System.out.println("Quantity: " + quantity);
        System.out.println("Total Price before Discount: " + totalPrice);
        System.out.println("Discount Rate: " + discountRate + "%");
        System.out.println("Discount Amount: " + discountAmount);
        System.out.println("Price after Discount: " + priceAfterDiscount);

       //close the scanner
        kira.close();
    }
}