/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */

//import scanner class
import java.util.Scanner; 

public class User {

    public static void main(String[] args) {
       
        Scanner user = new Scanner(System.in);

        //declare variables
        String name, hobby, favoriteFood;
        int age;

         //ask user to enter their name
        System.out.print("Enter your name: ");
        name = user.nextLine();

        // //ask user to enter their age
        System.out.print("Enter your age: ");
        age = user.nextInt();
        user.nextLine(); 

        // //ask user to enter their hobby
        System.out.print("Enter your hobby: ");
        hobby = user.nextLine();

         //ask user to enter their favorite food
        System.out.print("Enter your favorite food: ");
        favoriteFood = user.nextLine();

        //display the collected user information
        System.out.println("\nUser Information:");
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("Hobby: " + hobby);
        System.out.println("Favorite Food: " + favoriteFood);
        
        //close the scanner
        user.close();
    }
}