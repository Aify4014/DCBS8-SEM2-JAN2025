/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */

//import scanner class
import java.util.Scanner; 

public class ArithmeticProg {

    public static void main(String[] args) {
        
        //declare variables
        int num1, num2;
        
        Scanner nombor = new Scanner(System.in);
        
        //ask user to enter the first number 
        System.out.print("Enter the first integer: ");
        num1 = nombor.nextInt();

        //ask user to enter the second number
        System.out.print("Enter the second integer: ");
        num2 = nombor.nextInt();
        
        //arithmetic operators
        System.out.println("\nArithmetic Operations:");
        System.out.println(num1 + " + " + num2 + " = " + (num1 + num2)); // Addition
        System.out.println(num1 + " - " + num2 + " = " + (num1 - num2)); // Subtraction
        System.out.println(num1 + " * " + num2 + " = " + (num1 * num2)); // Multiplication
        System.out.println(num1 + " / " + num2 + " = " + (num1 / num2)); // Division
        System.out.println(num1 + " % " + num2 + " = " + (num1 % num2)); // Modulus
        
        //close the scanner
        nombor.close();
    }
}