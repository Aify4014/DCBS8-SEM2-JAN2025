/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */

//import scanner class
import java.util.Scanner;

public class AverageMarks {
    public static void main(String[] args) {
        
        Scanner Average = new Scanner(System.in);

        // Input student details
        //ask the user to enter student name 
        System.out.print("Enter student's name: ");
        String name = Average.nextLine();

        //ask the user to enter student ID
        System.out.print("Enter student ID: ");
        String id = Average.nextLine();

        //ask the user to enter subject name 
        System.out.print("Enter subject name: ");
        String subject = Average.nextLine();

        //ask the user to enter marks 
        System.out.print("Enter marks for Test 1 (/100): ");
        double test1 = Average.nextDouble();

        //ask the user to enter marks 
        System.out.print("Enter marks for Test 2 (/100): ");
        double test2 = Average.nextDouble();
        
        //calculate the average marks
        double average = (test1 + test2) / 2;
        
        //display student details and average marks
        System.out.println("\nStudent's Information and Average Marks:");
        System.out.println("Name: " + name);
        System.out.println("ID: " + id);
        System.out.println("Subject: " + subject);
        System.out.println("Average Marks: " + average);

        //close the scanner
        Average.close();
    }
}
