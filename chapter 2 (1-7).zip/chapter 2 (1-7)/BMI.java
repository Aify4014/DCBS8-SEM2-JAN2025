/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */

//import the scanner class
import java.util.Scanner;

public class BMI {
    public static void main(String[] args) {
        Scanner kiraberat = new Scanner(System.in);

        //ask the user to enter weight in kilograms
        System.out.print("Enter your weight in kilograms (kg): ");
        double weight = kiraberat.nextDouble();

        //ask the user to enter height in meters
        System.out.print("Enter your height in meters (m): ");
        double height = kiraberat.nextDouble();

        //calculate BMI using the formula: BMI = weight / (height * height)
        double bmi = weight / (height * height);

        //display the calculated BMI
        System.out.printf("Your BMI is: %.2f%n", bmi);

        //provide a simple interpretation of the BMI value
        if (bmi < 18.5) {
            System.out.println("You are underweight.");
        } else if (bmi >= 18.5 && bmi < 24.9) {
            System.out.println("You have a normal weight.");
        } else if (bmi >= 25 && bmi < 29.9) {
            System.out.println("You are overweight.");
        } else {
            System.out.println("You are obese.");
        }

        // close the scanner
        kiraberat.close();
    }
}