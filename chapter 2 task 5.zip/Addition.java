package hu2;

import javax.swing.JOptionPane;

public class Addition {
    public static void main(String[] args){
        String firstNumber;
        String secondNumber;
        String thirdNumber;
        String fourthNumber;
        int num1, num2, num3, num4, sum;
        
        firstNumber  =  JOptionPane.showInputDialog("Item Name");
        secondNumber =  JOptionPane.showInputDialog("Price");
        thirdNumber  =  JOptionPane.showInputDialog("Quantity");
        fourthNumber =  JOptionPane.showInputDialog("Discount rate");
        
        num1 = Integer.parseInt(firstNumber);
        num2 = Integer.parseInt(secondNumber);
        num3 = Integer.parseInt(thirdNumber);
        num4 = Integer.parseInt(fourthNumber);
        sum = num1 + num2 * num3+ num4;
        
        JOptionPane.showMessageDialog(null, "The item price is "+sum, "Results",
        JOptionPane.PLAIN_MESSAGE);
        System.exit(0);
    }
}