package hu2;

import javax.swing.*;

public class Average {
    public static void main(String[] args) {
        // Getting user input via pop-up dialogs!!!!!
        String name = JOptionPane.showInputDialog("Enter Name:");
        String id = JOptionPane.showInputDialog("Enter ID:");
        String subject = JOptionPane.showInputDialog("Enter Subject:");

        // Getting marks for tests!!!!!
        String test1Input = JOptionPane.showInputDialog("marks for Test 1? (/100):");
        int test1 = Integer.parseInt(test1Input);

        String test2Input = JOptionPane.showInputDialog("marks for Test 2? (/100):");
        int test2 = Integer.parseInt(test2Input);

        // Calculate average!!!!!
        int average = (int) ((test1 + test2) / 2.0);

        // Display the results in a pop-up!!!!!
        String result = String.format("Student Details:\nName: %s\nID: %s\nSubject: %s\nAverage Mark: %d%%",
                                      name, id, subject, average);
        JOptionPane.showMessageDialog(null, result);
    }
}